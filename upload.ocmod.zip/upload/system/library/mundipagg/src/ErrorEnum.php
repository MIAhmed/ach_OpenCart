<?php

class ErrorEnum
{
    const UNKNOWN_ORDER_STATUS =
        'Unknown order status received';
    
    const INVALID_CREDIT_CARD_REQUEST =
        'Invalid credit card request';
}
